package cn.ni.automessage;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.argument;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.literal;

public final class AutoMessageClient implements ClientModInitializer {
	public static final Logger LOGGER = LoggerFactory.getLogger("Simes/AutoMessage");
	private static AutoMessageConfig config;
	private static long nextSendAt;
	private static KeyBinding openScreenKey;

	@Override
	public void onInitializeClient() {
		config = AutoMessageConfig.load();
		scheduleNext();
		registerCommands();
		openScreenKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.automessage.open", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_O, "category.automessage"));

		ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
			config.enabled = false;
			scheduleNext();
		});
		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			while (openScreenKey.wasPressed()) {
				client.setScreen(new AutoMessageScreen());
			}
			if (!config.enabled || client.player == null || client.getNetworkHandler() == null) {
				return;
			}
			if (System.currentTimeMillis() >= nextSendAt) {
				send(client);
				scheduleNext();
			}
		});
	}

	private static void registerCommands() {
		ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> dispatcher.register(
				literal("automsg")
						.executes(context -> status(context.getSource()))
						.then(literal("status").executes(context -> status(context.getSource())))
						.then(literal("start").executes(context -> {
							config.enabled = true;
							scheduleNext();
							config.save();
							context.getSource().sendFeedback(Text.literal(
									"§a[自动消息] 已启动，每 " + config.intervalSeconds + " 秒发送一次"));
							return 1;
						}))
						.then(literal("stop").executes(context -> {
							config.enabled = false;
							config.save();
							context.getSource().sendFeedback(Text.literal("§e[自动消息] 已停止"));
							return 1;
						}))
						.then(literal("sendnow").executes(context -> {
							send(MinecraftClient.getInstance());
							scheduleNext();
							return 1;
						}))
						.then(literal("interval")
								.then(argument("seconds", IntegerArgumentType.integer(1, 86400))
										.executes(context -> {
											config.intervalSeconds = IntegerArgumentType.getInteger(context, "seconds");
											scheduleNext();
											config.save();
											context.getSource().sendFeedback(Text.literal(
													"§a[自动消息] 间隔已设为 " + config.intervalSeconds + " 秒"));
											return 1;
										})))
						.then(literal("message")
								.then(argument("content", StringArgumentType.greedyString())
										.executes(context -> {
											config.message = StringArgumentType.getString(context, "content");
											config.save();
											context.getSource().sendFeedback(Text.literal(
													"§a[自动消息] 内容已设为：" + config.message));
											return 1;
										})))
		));
	}

	private static int status(net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource source) {
		String state = config.enabled ? "§a运行中" : "§c已停止";
		source.sendFeedback(Text.literal("§6[自动消息] 状态：" + state
				+ "§r，间隔：" + config.intervalSeconds + " 秒，内容：" + config.message));
		return 1;
	}

	private static void send(MinecraftClient client) {
		if (client.getNetworkHandler() == null || config.message == null || config.message.isBlank()) {
			return;
		}
		if (config.message.startsWith("/")) {
			client.getNetworkHandler().sendChatCommand(config.message.substring(1));
		} else {
			client.getNetworkHandler().sendChatMessage(config.message);
		}
	}

	private static void scheduleNext() {
		nextSendAt = System.currentTimeMillis() + (long) config.intervalSeconds * 1000L;
	}

	static AutoMessageConfig config() {
		return config;
	}

	static void saveSettings(String message, int intervalSeconds) {
		config.message = message;
		config.intervalSeconds = intervalSeconds;
		config.save();
		scheduleNext();
	}

	static void setEnabled(boolean enabled) {
		config.enabled = enabled;
		config.save();
		scheduleNext();
	}

	static void sendNow() {
		send(MinecraftClient.getInstance());
		scheduleNext();
	}
}
