package cn.ni.automessage;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

public final class AutoMessageConfig {
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("automessage.json");

	public String message = "这是一条自动消息";
	public int intervalSeconds = 60;
	public transient boolean enabled;

	public static AutoMessageConfig load() {
		if (!Files.exists(PATH)) {
			return new AutoMessageConfig();
		}
		try (Reader reader = Files.newBufferedReader(PATH)) {
			AutoMessageConfig config = GSON.fromJson(reader, AutoMessageConfig.class);
			return config == null ? new AutoMessageConfig() : config;
		} catch (Exception exception) {
			AutoMessageClient.LOGGER.error("读取配置失败，将使用默认配置", exception);
			return new AutoMessageConfig();
		}
	}

	public void save() {
		try {
			Files.createDirectories(PATH.getParent());
			try (Writer writer = Files.newBufferedWriter(PATH)) {
				GSON.toJson(this, writer);
			}
		} catch (IOException exception) {
			AutoMessageClient.LOGGER.error("保存配置失败", exception);
		}
	}
}
