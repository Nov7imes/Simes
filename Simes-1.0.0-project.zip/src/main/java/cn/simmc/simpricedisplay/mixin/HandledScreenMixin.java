package cn.simmc.simpricedisplay.mixin;

import cn.simmc.simpricedisplay.CoordinateCopyController;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.screen.slot.Slot;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(HandledScreen.class)
public abstract class HandledScreenMixin {
	@Shadow @Nullable protected Slot focusedSlot;

	@Inject(method = "keyPressed", at = @At("HEAD"), cancellable = true)
	private void simes$copyShopCoordinates(
			int keyCode,
			int scanCode,
			int modifiers,
			CallbackInfoReturnable<Boolean> callback
	) {
		HandledScreen<?> screen = (HandledScreen<?>)(Object)this;
		if (screen.getFocused() instanceof TextFieldWidget) {
			return;
		}
		if (CoordinateCopyController.handleKey(focusedSlot, keyCode, scanCode)) {
			callback.setReturnValue(true);
		}
	}

	@Inject(method = "mouseClicked", at = @At("HEAD"), cancellable = true)
	private void simes$copyShopCoordinatesWithMouse(
			double mouseX,
			double mouseY,
			int button,
			CallbackInfoReturnable<Boolean> callback
	) {
		if (CoordinateCopyController.handleMouse(focusedSlot, button)) {
			callback.setReturnValue(true);
		}
	}
}
